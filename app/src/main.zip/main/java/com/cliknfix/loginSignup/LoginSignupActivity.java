package com.cliknfix.loginSignup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.cliknfix.R;
import com.cliknfix.base.BaseClass;
import com.cliknfix.login.LoginActivity;
import com.cliknfix.signUp.SignUpActivity;
import com.cliknfix.util.Utility;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LoginSignupActivity extends BaseClass {

    @BindView(R.id.tv_welcome)
    TextView tvWelcome;
    @BindView(R.id.tv_ptext1)
    TextView tvP1;
    @BindView(R.id.tv_ptext2)
    TextView tvP2;
    @BindView(R.id.tv_ptext3)
    TextView tvP3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_signup);
        ButterKnife.bind(this);
        init();
    }

    private void init() {
        ((TextView) tvWelcome).setTypeface(Utility.typeFaceForText(this));
        ((TextView) tvP1).setTypeface(Utility.typeFaceForText(this));
        ((TextView) tvP2).setTypeface(Utility.typeFaceForText(this));
        ((TextView) tvP3).setTypeface(Utility.typeFaceForText(this));
    }

    public void onLoginClicked(View view) {
        startActivity(new Intent(this, LoginActivity.class));
    }

    public void onSignupClicked(View view) {
        startActivity(new Intent(this, SignUpActivity.class));
    }
}
