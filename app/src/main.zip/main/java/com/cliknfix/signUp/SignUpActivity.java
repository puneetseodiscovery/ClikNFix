package com.cliknfix.signUp;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.cliknfix.R;
import com.cliknfix.base.BaseClass;
import com.cliknfix.login.LoginActivity;
import com.cliknfix.retrofit.APIInterface;
import com.cliknfix.util.Utility;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SignUpActivity extends BaseClass implements ISignUpActivity {

    @BindView(R.id.tv_signup)
    TextView tvSignUp;
    @BindView(R.id.et_signup_username)
    EditText etUsername;
    @BindView(R.id.et_signup_email)
    EditText etEmail;
    @BindView(R.id.et_age_signup)
    EditText etAge;
    @BindView(R.id.et_bld_grp_signup)
    EditText etBldGrp;
    @BindView(R.id.et_address_signup)
    EditText etAddress;
    @BindView(R.id.et_password_signup)
    EditText etPassword;
    @BindView(R.id.et_cnfrm_password_signup)
    EditText etCnfrmPass;
    @BindView(R.id.btn_signup)
    Button btnSignup;
    @BindView(R.id.tv_or)
    TextView tvOr;
    @BindView(R.id.btn_login)
    Button btnLogin;

    IPSignUp ipSignUp;

    ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        ButterKnife.bind(this);
        ipSignUp = new PSignUp(this);
        init();
    }

    public void onSignUpButtonClicked(View view) {
        if (Utility.isNetworkConnected(this)) {

            if (etUsername.getText().toString().length()>0 && etEmail.getText().toString().length()>0 && etAge.getText().toString().length()>0
                    && etBldGrp.getText().toString().length()>0 && etAddress.getText().toString().length()>0 && etPassword.getText().toString().length()>0)
            {

                if (Utility.validEmail(etEmail.getText().toString().trim()))
                {
                    if (etPassword.getText().toString().equals(etCnfrmPass.getText().toString())) {

                        if (etPassword.getText().toString().length()>=6)
                        {

                            if (isValidPassword(etPassword.getText().toString().trim()))
                            {
                                progressDialog = Utility.showLoader(this);
                                ipSignUp.doSignUp(etUsername.getText().toString().trim(), etEmail.getText().toString().trim().toLowerCase(), etAge.getText().toString().trim(), etBldGrp.getText().toString().trim(), etAddress.getText().toString().trim(), etPassword.getText().toString().trim());
                            }
                            else
                            {

                                etPassword.setError("Alphanumeric password needed.");
                                etPassword.requestFocus();
                            }

                        }
                        else {
                            etPassword.setError("Minimum 6 characters.");
                            etPassword.requestFocus();

                        }


                    }
                    else
                    {
                        //Toast.makeText(this, "Password do not match.", Toast.LENGTH_SHORT).show();
                        etCnfrmPass.setError("Password not matched.");
                        etCnfrmPass.requestFocus();
                    }

                }
                else
                {
                    etEmail.setError("Enter an  valid email.");
                    etEmail.requestFocus();
                    //Toast.makeText(this, "Enter an  valid email.", Toast.LENGTH_SHORT).show();
                }

            }
            else
            {
                //Toast.makeText(this, "Enter correct signup details.", Toast.LENGTH_SHORT).show();
                if (etUsername.getText().toString().length()==0 && etEmail.getText().toString().length()==0 && etAge.getText().toString().length()==0
                        && etBldGrp.getText().toString().length()==0 && etAddress.getText().toString().length()==0 && etPassword.getText().toString().length()==0
                        && etCnfrmPass.getText().toString().length()==0)
                {
                    etUsername.setError("Enter full name");
                    etUsername.requestFocus();
                    etEmail.setError("Enter email");
                    etAge.setError("Enter mobile number");
                    etBldGrp.setError("Enter password");
                    etAddress.setError("Confirm password");
                    etPassword.setError("Select gender");
                    etCnfrmPass.setError("Enter age");
                }
                else if (etUsername.getText().toString().length()==0)
                {
                    etUsername.setError("Enter Username");
                    etUsername.requestFocus();
                }
                else if (etEmail.getText().toString().length()==0)
                {
                    etEmail.setError("Enter email");
                    etEmail.requestFocus();
                }
                else if (etAge.getText().toString().length()==0)
                {
                    etAge.setError("Enter age");
                    etAge.requestFocus();
                }
                else if (etBldGrp.getText().toString().length()==0)
                {
                    etBldGrp.setError("Enter blood group");
                    etBldGrp.requestFocus();
                }
                else if (etAddress.getText().toString().length()==0)
                {
                    etAddress.setError("Enter address");
                    etAddress.requestFocus();
                }
                else if (etPassword.getText().toString().length()==0)
                {
                    etPassword.setError("Enter password");
                    etPassword.requestFocus();
                }
                else if (etCnfrmPass.getText().toString().length()==0)
                {
                    etCnfrmPass.setError("Enter confirm password");
                    etCnfrmPass.requestFocus();
                }
            }

        }
        else
        {
            Toast.makeText(this, "Check your internet connection !!!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onSignUpResponseFromPresenter(String statusValue,int otp) {
        progressDialog.dismiss();

        if (otp!= APIInterface.SIGNUP_FAILED) {

            //startActivity(new Intent(this, OtpActivity.class).putExtra("otp", otp).putExtra("mobileNumber",mobileNumber.getText().toString()));
            finish();
        }
        else
        {
                Toast.makeText(this, ""+statusValue, Toast.LENGTH_SHORT).show();
        }
    }

    public void onBackLayoutClicked(View view) {

        onBackPressed();
    }

    public void init()
    {
        tvSignUp.setTypeface(Utility.typeFaceForBoldText(this));
        etUsername.setTypeface(Utility.typeFaceForText(this));
        etEmail.setTypeface(Utility.typeFaceForBoldText(this));
        etAge.setTypeface(Utility.typeFaceForText(this));
        etBldGrp.setTypeface(Utility.typeFaceForText(this));
        etAddress.setTypeface(Utility.typeFaceForText(this));
        etPassword.setTypeface(Utility.typeFaceForText(this));
        etCnfrmPass.setTypeface(Utility.typeFaceForText(this));
        btnSignup.setTypeface(Utility.typeFaceForBoldText(this));
        tvOr.setTypeface(Utility.typeFaceForText(this));
        btnLogin.setTypeface(Utility.typeFaceForBoldText(this));

        //gender.setOnClickListener(this);
        etEmail.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    // code to execute when EditText loses focus

                    if (etEmail.getText().toString().length()>0) {
                        if (!Utility.validEmail(etEmail.getText().toString().trim()))
                            etEmail.setError("Invalid email");
                        etEmail.requestFocus();
                    } else {
                        etEmail.setError(null);
                    }
                }
            }
        });
    }

    public static boolean isValidPassword(final String password) {

        String pattern= "^[a-zA-Z0-9]@*$";
        return password.matches(pattern);

    }

    public void onLoginButtonClicked(View view) {
        startActivity(new Intent(this, LoginActivity.class));
    }
}
