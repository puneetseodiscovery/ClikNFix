package com.cliknfix.signUp;

public interface IModleSignUpActivity {

    void signUpRestCall(BeanModelSignUp beanModelSignUp);
}
