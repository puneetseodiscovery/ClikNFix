package com.cliknfix.signUp;

public interface ISignUpActivity {

    void onSignUpResponseFromPresenter(String statusValue, int otp);
}
