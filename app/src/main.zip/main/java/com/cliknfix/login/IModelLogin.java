package com.cliknfix.login;

public interface IModelLogin {

    void loginRestCall();

}
