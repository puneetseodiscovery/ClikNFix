package com.cliknfix.forgotPassword;

public interface IModelForgotPasswordActivity {

    void forgotPasswordRestCall(String phoneNumber);

}
