package com.cliknfix.homeScreen.bottomFragments.model;

public class BeanHomeFragment {

    int catImg,frwdImg;
    String catName;

    public BeanHomeFragment(int catImg, int frwdImg, String catName) {
        this.catImg = catImg;
        this.frwdImg = frwdImg;
        this.catName = catName;
    }

    public int getCatImg() {
        return catImg;
    }

    public void setCatImg(int catImg) {
        this.catImg = catImg;
    }

    public int getFrwdImg() {
        return frwdImg;
    }

    public void setFrwdImg(int frwdImg) {
        this.frwdImg = frwdImg;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

}
