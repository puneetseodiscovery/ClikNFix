package com.cliknfix.homeScreen.bottomFragments.model;

public class JMHomeFragment extends IMHomeFragment{
}
