package com.cliknfix.homeScreen.bottomFragments;

import com.cliknfix.responseModels.UserModelLoginResponse;

public class IHomeFragment {


}
