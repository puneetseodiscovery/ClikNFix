package com.cliknfix.mobile;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.cliknfix.R;
import com.cliknfix.base.BaseClass;
import com.cliknfix.util.Utility;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MobileNoActivity extends BaseClass
{
    @BindView(R.id.tv_mobile_screen)
    TextView tvP1;
    @BindView(R.id.tv_mobile_screen1)
    TextView tvP2;
    @BindView(R.id.tv_country_code)
    TextView tvCC;
    @BindView(R.id.et_mobile_no)
    EditText etMobile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mobile_no);
        ButterKnife.bind(this);
        init();
    }

    public void init() {
        tvP1.setTypeface(Utility.typeFaceForText(this));
        tvP2.setTypeface(Utility.typeFaceForText(this));
        tvCC.setTypeface(Utility.typeFaceForText(this));
        etMobile.setTypeface(Utility.typeFaceForText(this));
    }

    public void onNextClicked(View view) {

    }


}
